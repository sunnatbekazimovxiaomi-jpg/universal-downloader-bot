from telegram import Update
from telegram.ext import ApplicationBuilder, MessageHandler, filters, ContextTypes
import yt_dlp
import os

BOT_TOKEN = "8272092082:AAH_M_BazE3_AQX3EBG8NtUDEvtAQBBdwUo"

async def download_video(update: Update, context: ContextTypes.DEFAULT_TYPE):
    url = update.message.text.strip()
    await update.message.reply_text("📥 Yuklanmoqda, biroz kuting...")

    filename = "video.mp4"
    ydl_opts = {'outtmpl': filename, 'format': 'best', 'quiet': True, 'noplaylist': True}

    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            ydl.download([url])
        await update.message.reply_video(video=open(filename, "rb"))
        await update.message.reply_text("✅ Yuklab bo‘ldi!")
        os.remove(filename)
    except Exception as e:
        await update.message.reply_text(f"❌ Xatolik: {e}")

app = ApplicationBuilder().token(BOT_TOKEN).build()
app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, download_video))
app.run_polling()
